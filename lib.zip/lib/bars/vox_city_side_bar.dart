import 'package:flutter/material.dart';
import 'package:voxcity/screens/vox/forecast_screen.dart';
import 'package:voxcity/screens/vox/vox_wave.dart';
import 'package:voxcity/screens/vox/whatsapp_web_screen.dart';
import 'package:voxcity/screens/vox/vox_zendesk_screen.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../demo.dart';

class VoxSideBar extends StatefulWidget {
  const VoxSideBar({super.key});

  @override
  VoxSideBarState createState() => VoxSideBarState();
}

class VoxSideBarState extends State<VoxSideBar> with SingleTickerProviderStateMixin {
  int _selectedPage = 0;
  bool _isSidebarVisible = false;

  final List<Map<String, dynamic>> _pages = [
    {"icon": FontAwesomeIcons.whatsapp, "label": "WhatsApp", "page": const WebWhatsAppScreen()},
    {"icon": FontAwesomeIcons.z, "label": "Zendesk", "page": const ZendeskScreen()},
    {"icon": FontAwesomeIcons.w, "label": "Wave", "page": const VoxWave()},
    {"icon": Icons.search, "label": "Forecast", "page": const BookingForecastScreen()},
  ];

  late final AnimationController _animationController;
  late final Animation<double> _widthAnimation;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    _widthAnimation = Tween<double>(begin: 0, end: 200).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _toggleSidebar(bool show) {
    if (show) {
      _animationController.forward();
    } else {
      _animationController.reverse();
    }
    setState(() {
      _isSidebarVisible = show;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Main content area
          Positioned.fill(
            child: IndexedStack(
              index: _selectedPage,
              children: _pages.map((page) => page["page"] as Widget).toList(),
            ),
          ),
          // Sidebar
          Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            child: MouseRegion(
              onEnter: (_) => _toggleSidebar(true),
              onExit: (_) => _toggleSidebar(false),
              child: AnimatedBuilder(
                animation: _widthAnimation,
                builder: (context, child) {
                  return Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    width: _widthAnimation.value,
                    color: Colors.grey[900],
                    child: _widthAnimation.value > 0
                        ? Column(
                      children: List.generate(_pages.length, (index) {
                        final bool isSelected = _selectedPage == index;
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedPage = index;
                            });
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            margin: const EdgeInsets.symmetric(vertical: 8),
                            padding: const EdgeInsets.symmetric(
                                vertical: 12, horizontal: 10),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Colors.grey,
                                width: 1
                              ),
                              color: isSelected
                                  ? Colors.blue[700]
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              children: [
                                Flexible(
                                  flex:1,
                                  child: Icon(
                                    _pages[index]["icon"],
                                    color: isSelected
                                        ? Colors.white
                                        : Colors.grey[400],
                                  ),
                                ),
                                const SizedBox(width: 10),
                                if (_widthAnimation.value > 100)
                                  Flexible(
                                    flex:2,
                                    child: Text(
                                      _pages[index]["label"],
                                      style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : Colors.grey[400],
                                        fontSize: 16,
                                        fontWeight: isSelected
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        );
                      }),
                    )
                        : null,
                  );
                },
              ),
            ),
          ),
          // Invisible detection area for expanding the sidebar
          Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            width: 20,
            child: MouseRegion(
              onEnter: (_) => _toggleSidebar(true),
            ),
          ),
        ],
      ),
    );
  }
}