import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:voxcity/screens/slack_screen.dart';
import 'package:voxcity/bars/vox_city_side_bar.dart';
import 'package:voxcity/bars/yes_milano_side_bar.dart';

class TabNavigationScreen extends StatefulWidget {
  const TabNavigationScreen({super.key});

  @override
  TabNavigationScreenState createState() => TabNavigationScreenState();
}

class TabNavigationScreenState extends State<TabNavigationScreen> {
  int _currentIndex = 0;

  final List<Map<String, dynamic>> _pages = [
    {"icon": FontAwesomeIcons.v, "page": const VoxSideBar()},
    {"icon": FontAwesomeIcons.y, "page": const YMSideBar()},
    {"icon": FontAwesomeIcons.slack, "page": const SlackScreen()},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // Main content area
          Expanded(
            child: IndexedStack(
              index: _currentIndex,
              children: _pages.map((page) => page["page"] as Widget).toList(),
            ),
          ),
          // Right-side navigation bar
          Container(
            width: 80,
            color: Colors.grey[900],
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_pages.length, (index) {
                final bool isSelected = _currentIndex == index;
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _currentIndex = index;
                    });
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.symmetric(vertical: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.blue : Colors.transparent,
                      shape: BoxShape.circle,
                      boxShadow: isSelected
                          ? [
                        BoxShadow(
                          color: Colors.blue.withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        )
                      ]
                          : null,
                    ),
                    child: FaIcon(
                      _pages[index]["icon"],
                      color: isSelected ? Colors.white : Colors.grey[400],
                      size: 24,
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}