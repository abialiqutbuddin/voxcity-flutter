import 'package:flutter/material.dart';
import 'package:voxcity/controller/multi_file.dart';
import '../../controller/product_bookings_controller.dart';
import 'directory_screen.dart';

class CustomerDetailsScreen extends StatefulWidget {
  final String date;
  final String optionId;

  const CustomerDetailsScreen(
      {super.key, required this.date, required this.optionId});

  @override
  CustomerDetailsScreenState createState() => CustomerDetailsScreenState();
}

class CustomerDetailsScreenState extends State<CustomerDetailsScreen> {
  List<Map<String, dynamic>> customers = [];
  bool isLoading = true;
  late ProductBookingsController controller;

  @override
  void initState() {
    super.initState();
    controller = ProductBookingsController(widget.optionId, widget.date);
    controller.fetchCustomer(updateLoadingState, updateCustomerState);
  }

  void updateLoadingState(bool loading) {
    setState(() {
      isLoading = loading;
    });
  }

  void updateCustomerState(item) {
    setState(() {
      customers = item;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Customer Details'),
        backgroundColor: Colors.deepPurpleAccent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton.icon(
                      icon: const Icon(Icons.copy, color: Colors.white),
                      label: const Text("Copy All"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      onPressed: () {
                        controller.copyAllCustomersToClipboard(context);
                      },
                    ),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.call_split_rounded,
                          color: Colors.white),
                      label: const Text("Split Tickets"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purpleAccent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      onPressed: () {
                        _openMultiDirectoryDialog(
                            context,
                            "1lvelAgggBucbgMMJu9Zpd8baRZrQWvtP",
                            "Root Directory",
                            customers
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: ListView(
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Wrap(
                          spacing: 8.0, // Horizontal space between cards
                          runSpacing: 8.0, // Vertical space between rows
                          children: customers.map((customer) {
                            return ConstrainedBox(
                              constraints: const BoxConstraints(
                                minWidth: 200, // Minimum width for each card
                                maxWidth: 330, // Maximum width for each card
                              ),
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                elevation: 4,
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SelectableText(
                                        customer['guestName'],
                                        style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.deepPurpleAccent,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      _buildDetailRow(
                                          "Booking ID:", customer['bookingId']),
                                      _buildDetailRow(
                                          "Provider:", customer['provider']),
                                      _buildDetailRow(
                                          "Date/Time:", customer['dateTime']),
                                      _buildDetailRow(
                                          "Email:", customer['email']),
                                      _buildDetailRow(
                                          "Phone:", customer['phone']),
                                      _buildDetailRow(
                                          "Pax:", customer['pax'].toString()),
                                      const Divider(),
                                      const SizedBox(height: 8),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          IconButton(
                                            icon: const Icon(Icons.download,
                                                color: Colors.white),
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor:
                                                  Colors.blueAccent,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                            onPressed: () async {
                                              updateLoadingState(true);
                                              final bookingId =
                                                  customer['bookingId'];
                                              await controller
                                                  .handleVoucherDownload(
                                                      bookingId);
                                              updateLoadingState(false);
                                              ScaffoldMessenger.of(context)
                                                  .showSnackBar(
                                                const SnackBar(
                                                  content: Text(
                                                      "Voucher PDF content copied to clipboard"),
                                                ),
                                              );
                                            },
                                          ),
                                          IconButton(
                                            icon: const Icon(Icons.upload_file,
                                                color: Colors.white),
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor:
                                                  Colors.orangeAccent,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                            onPressed: () {
                                              _openDirectoryDialog(context, "1lvelAgggBucbgMMJu9Zpd8baRZrQWvtP", "Root Directory",
                                                customer['bookingId'].substring(1));
                                            },
                                          ),
                                          IconButton(
                                            icon: const Icon(Icons.message,
                                                color: Colors.white),
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.green,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                            onPressed: () {
                                              controller.handleOnPressed(customer, 'message', context, updateLoadingState);
                                            },
                                          ),
                                          IconButton(
                                            icon: const Icon(
                                                Icons.email_outlined,
                                                color: Colors.white),
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.grey,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                            onPressed: () async {
                                              controller.handleOnPressed(
                                                  customer,
                                                  'email',
                                                  context,
                                                  updateLoadingState);
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (isLoading)
            Container(
              color: Colors.black.withOpacity(0.5), // Semi-transparent overlay
              child: const Center(
                child: CircularProgressIndicator(
                  color: Colors.white,
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _openDirectoryDialog(BuildContext context, String folderId,
      String folderName, String bookingCode) {
    showDialog(
      context: context,
      barrierDismissible: false, // Prevents closing on tap outside
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0), // Rounded corners
          ),
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  height: MediaQuery.of(context).size.height *
                      0.6, // Adjust height as needed
                  width: MediaQuery.of(context).size.width *
                      0.8, // Adjust width as needed
                  child: DirectoryPage(
                    folderId: folderId,
                    folderName: folderName,
                    bookingCode: bookingCode,
                  ),
                ),
              ),
              Positioned(
                top: 8.0,
                right: 8.0,
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(), // Close dialog
                  child: Container(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.red,
                    ),
                    child: const Icon(
                      Icons.close,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _openMultiDirectoryDialog(BuildContext context, String folderId,
      String folderName, List<Map<String, dynamic>> customers ) {
    showDialog(
      context: context,
      barrierDismissible: false, // Prevents closing on tap outside
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0), // Rounded corners
          ),
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  height: MediaQuery.of(context).size.height *
                      0.6, // Adjust height as needed
                  width: MediaQuery.of(context).size.width *
                      0.8, // Adjust width as needed
                  child: MultiDirectoryPage(
                    folderId: folderId,
                    folderName: folderName,
                    customers: customers,
                  ),
                ),
              ),
              Positioned(
                top: 8.0,
                right: 8.0,
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(), // Close dialog
                  child: Container(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.red,
                    ),
                    child: const Icon(
                      Icons.close,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: SelectableText(
              value,
              style: const TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
