import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:voxcity/api/api.dart';
import 'package:voxcity/screens/vox/big_bus_screen.dart';
import 'package:voxcity/screens/vox/product_bookings_screen.dart';
import 'package:voxcity/screens/vox/walker_screen.dart';
import 'package:voxcity/screens/vox/whatsapp_web_screen.dart';

class BookingForecastScreen extends StatefulWidget {
  const BookingForecastScreen({super.key});

  @override
  BookingForecastScreenState createState() => BookingForecastScreenState();
}

class BookingForecastScreenState extends State<BookingForecastScreen>
    with AutomaticKeepAliveClientMixin {

  @override
  bool get wantKeepAlive => true; // Keeps the widget alive

  List<dynamic> todaysBookings = [];
  List<dynamic> tomorrowsBookings = [];
  bool isSidebarExpanded = false;

  @override
  void dispose() {
    // Clean up any resources to avoid memory leaks
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    fetchBookingForecast();
  }

  Future<void> fetchBookingForecast() async {
    try {
      final response =
          await http.get(Uri.parse('${Wave.ip}get-booking-forecast'));

      if (response.statusCode == 200) {
        List<dynamic> allBookings = json.decode(response.body)['bookings'];
        DateTime today = DateTime.now();
        DateTime tomorrow = today.add(const Duration(days: 1));

        setState(() {
          todaysBookings = allBookings.where((booking) {
            int bookingDay = int.parse(booking['date'].toString());
            return bookingDay == today.day;
          }).toList();

          tomorrowsBookings = allBookings.where((booking) {
            int bookingDay = int.parse(booking['date'].toString());
            return bookingDay == tomorrow.day;
          }).toList();
        });
      } else {
        print(
            'Failed to load booking forecast. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching bookings: $e');
    }
  }

  void openCustomerDetails(String detailLink) {
    final uri = Uri.parse(detailLink);
    final date = uri.queryParameters['date'] ?? '';
    final optionId = uri.queryParameters['option_id'] ?? '';

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            CustomerDetailsScreen(date: date, optionId: optionId),
      ),
    );
  }

  bool isHovering = false;
  bool isHoveringW = false;


  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: const Text('Booking Forecast'),
        backgroundColor: Colors.blueGrey,
      ),
      body: Row(
        children: [
          Container(
            decoration: const BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(8),
                    bottomRight: Radius.circular(8))),
            width: 50,
            child: Column(
              children: [
                const SizedBox(
                  height: 20,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const BookingPage(),
                      ),
                    );
                  },
                  child: MouseRegion(
                    cursor: SystemMouseCursors.click, // Change pointer on hover
                    onEnter: (_) {
                      setState(() {
                        isHoveringW = true;
                      });
                    },
                    onExit: (_) {
                      setState(() {
                        isHoveringW = false;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 100), // Smooth zoom animation
                      width: isHoveringW ? 35 : 30, // Slight zoom on hover
                      height: isHoveringW ? 35 : 30, // Slight zoom on hover
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(
                            5), // Match the Container's border radius
                        child: Image.asset(
                          "assets/walkers.png",
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const BigBusBookingPage(),
                      ),
                    );
                  },
                  child: MouseRegion(
                    cursor: SystemMouseCursors.click, // Change pointer on hover
                    onEnter: (_) {
                      setState(() {
                        isHovering = true;
                      });
                    },
                    onExit: (_) {
                      setState(() {
                        isHovering = false;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 100), // Smooth zoom animation
                      width: isHovering ? 35 : 30, // Slight zoom on hover
                      height: isHovering ? 35 : 30, // Slight zoom on hover
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(
                            5), // Match the Container's border radius
                        child: Image.asset(
                          "assets/big-bus.png",
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 6,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Bookings Overview',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 20),
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            child: buildBookingSection("Today", todaysBookings,
                                Colors.green, Colors.green[50]!),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: buildBookingSection(
                                "Tomorrow",
                                tomorrowsBookings,
                                Colors.blue,
                                Colors.blue[50]!),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildBookingSection(String label, List<dynamic> bookings, Color color,
      Color backgroundColor) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
                fontSize: 20, fontWeight: FontWeight.bold, color: color),
          ),
          const SizedBox(height: 8),
          if (bookings.isEmpty)
            Text("No bookings for ${label.toLowerCase()}")
          else
            Expanded(
              child: ListView.builder(
                itemCount: bookings.length,
                itemBuilder: (context, index) {
                  final booking = bookings[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: booking['products'].map<Widget>((product) {
                          return ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.tour, color: color),
                            title: Text(
                              product['productName'],
                              style:
                                  const TextStyle(fontWeight: FontWeight.w600),
                            ),
                            subtitle:
                                Text('Bookings: ${product['bookingsCount']}'),
                            trailing:
                                Icon(Icons.arrow_forward_ios, color: color),
                            onTap: () =>
                                openCustomerDetails(product['detailLink']),
                          );
                        }).toList(),
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
