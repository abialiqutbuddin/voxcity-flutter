import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:file_picker/file_picker.dart';

import '../../bars/top_bar.dart';
import '../../storage/secure_storage.dart';

class VoxWave extends StatefulWidget {
  const VoxWave({Key? key}) : super(key: key);

  @override
  _VoxWaveState createState() => _VoxWaveState();
}

class _VoxWaveState extends State<VoxWave> with AutomaticKeepAliveClientMixin {
  late InAppWebViewController _webViewController;

  @override
  void initState() {
    super.initState();
  }

  Future<void> autofillLogin(InAppWebViewController controller) async {
    final credentials = await getVoxWaveLoginInfo();
    final username = credentials['username'];
    final password = credentials['password'];

    if (username != null && password != null) {
      await controller.evaluateJavascript(source: """
      (function() {
        const emailField = document.querySelector('input#user_email') || document.querySelector('input[name="user[email]"]');
        const passwordField = document.querySelector('input#user_password') || document.querySelector('input[name="user[password]"]');
        
        if (emailField && passwordField) {
          emailField.value = '$username';
          passwordField.value = '$password';

          emailField.dispatchEvent(new Event('input', { bubbles: true }));
          passwordField.dispatchEvent(new Event('input', { bubbles: true }));
        }
      })();
    """);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
      body: Stack(
        children: [
          // InAppWebView content
          InAppWebView(
            initialUrlRequest: URLRequest(url: WebUri("https://wave.live")),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              useShouldOverrideUrlLoading: true,
              mediaPlaybackRequiresUserGesture: false,
            ),
            onWebViewCreated: (controller) {
              _webViewController = controller;
            },
            onLoadStart: (controller, url) {
              print("Page started loading: $url");
            },
            onLoadStop: (controller, url) async {
              print("Page finished loading: $url");
              saveVoxWaveLoginInfo('ben@voxcity.com', 'VoxCity4Ben@2023!');
              // Optional: Trigger autofill
              autofillLogin(controller);
            },
            shouldOverrideUrlLoading: (controller, navigationAction) async {
              final uri = navigationAction.request.url;
              if (uri != null && uri.toString().contains("file-upload")) {
                final result = await FilePicker.platform.pickFiles();
                if (result != null) {
                  print("Selected file: ${result.files.single.name}");
                  // Handle file upload logic
                }
                return NavigationActionPolicy.CANCEL;
              }
              if (uri != null && (uri.toString().endsWith(".pdf") || uri.toString().endsWith(".zip"))) {
                print("Download detected: $uri");
                // Handle download logic
                return NavigationActionPolicy.CANCEL;
              }
              return NavigationActionPolicy.ALLOW;
            },
          ),
          // Top Bar
          TopBar(
            title: 'Vox Wave',
            actions: [
              IconButton(
                tooltip: 'Refresh',
                icon: const Icon(Icons.refresh, color: Colors.white),
                onPressed: () {
                  _webViewController.reload();
                },
              ),
              IconButton(
                tooltip: 'Go Back',
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () {
                  _webViewController.goBack();
                },
              ),
              IconButton(
                tooltip: 'Go Forward',
                icon: const Icon(Icons.arrow_forward, color: Colors.white),
                onPressed: () {
                  _webViewController.goForward();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  bool get wantKeepAlive => true; // Keeps the widget alive in memory
}