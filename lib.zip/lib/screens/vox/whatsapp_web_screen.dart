import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:file_selector/file_selector.dart';
import '../../bars/top_bar.dart';
import 'package:super_drag_and_drop/super_drag_and_drop.dart';

class WebWhatsAppScreen extends StatefulWidget {
  const WebWhatsAppScreen({Key? key}) : super(key: key);

  @override
  _WebWhatsAppScreenState createState() => _WebWhatsAppScreenState();
}

class _WebWhatsAppScreenState extends State<WebWhatsAppScreen>
    with AutomaticKeepAliveClientMixin, WidgetsBindingObserver {
  InAppWebViewController? _webViewController;
  final ValueNotifier<int> unreadCountNotifier = ValueNotifier(0);
  List<Map<String, String>> downloadQueue = [];
  Offset popupPosition = const Offset(300, 50); // Initial position of the download popup

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unreadCountNotifier.dispose();
    super.dispose();
  }

  Future<void> _fetchUnreadCount() async {
    try {
      final unreadCount = await _webViewController?.evaluateJavascript(source: """
        (function() {
          let count = 0;
          const parentElements = document.querySelectorAll('.x10l6tqk.x14ipxcb.x1oozmrk');
          parentElements.forEach((parent) => {
            const unreadSpan = parent.querySelector('span[aria-label*="unread messages"]');
            if (unreadSpan) {
              const ariaLabel = unreadSpan.getAttribute('aria-label');
              const text = ariaLabel.match(/\\d+/);
              if (text) count += parseInt(text[0]);
            }
          });
          return count;
        })();
      """);
      unreadCountNotifier.value = int.tryParse(unreadCount.toString()) ?? 0;
    } catch (e) {
      print("Error fetching unread count: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
      body:
      Stack(
        children: [
          // Main WebView content
          InAppWebView(
            initialUrlRequest: URLRequest(
              url: WebUri('https://web.whatsapp.com'),
            ),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              useShouldOverrideUrlLoading: true,
              mediaPlaybackRequiresUserGesture: false,
              userAgent:
              'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', // Mimic Chrome
            ),
            onWebViewCreated: (controller) {
              _webViewController = controller;
              // Add JavaScript handler for blob downloads
              _webViewController?.addJavaScriptHandler(
                handlerName: 'downloadBlob',
                callback: (args) async {
                  final String base64Data = args[0];
                  final String fileName = args[1] ?? 'downloaded_file';
                  await _saveBlobToFile(base64Data, fileName);
                },
              );
            },
            onLoadStart: (controller, url) {
              print("Page started loading: $url");
            },
            onLoadStop: (controller, url) async {
              print("Page finished loading: $url");
            },
            shouldOverrideUrlLoading: (controller, navigationAction) async {
              // Example: Add logic for custom navigation actions if needed
              return NavigationActionPolicy.ALLOW;
            },
            onConsoleMessage: (controller, consoleMessage) {
              // Print JavaScript console logs to the Flutter console
              print("JS Console: ${consoleMessage.messageLevel} - ${consoleMessage.message}");
            },
            onDownloadStartRequest: (controller, downloadStartRequest) async {
              final downloadUrl = downloadStartRequest.url.toString();
              // print("Download started: $downloadUrl");
              // await _handleDownload(downloadUrl);
              print("Blob URL detected: $downloadUrl");

              await _webViewController?.evaluateJavascript(source: """
              (async function() {
                const blob = await fetch('$downloadUrl').then(r => r.blob());
                const reader = new FileReader();
                reader.onloadend = function() {
                  const base64Data = reader.result.split(',')[1];
                  window.flutter_inappwebview.callHandler('downloadBlob', base64Data, 'downloaded_file.pdf');
                };
                reader.readAsDataURL(blob);
              })();
            """);
            },
          ),
          // Top Bar
          TopBar(
            title: 'Vox Zendesk',
            actions: [
              IconButton(
                tooltip: 'Refresh',
                icon: const Icon(Icons.refresh, color: Colors.white),
                onPressed: () {
                  if (_webViewController != null) {
                    _webViewController!.reload();
                  }                },
              ),
              IconButton(
                tooltip: 'Go Back',
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () {
                  if (_webViewController != null) {
                    _webViewController!.goBack();
                  }                },
              ),
              IconButton(
                tooltip: 'Go Forward',
                icon: const Icon(Icons.arrow_forward, color: Colors.white),
                onPressed: () {
                  if (_webViewController != null) {
                    _webViewController!.goForward();
                  }                },
              ),
            ],
          ),
          Positioned(
            left: 20,
            top: 20,
            child: DownloadPopup(
              onDismiss: () {
                setState(() {
                  downloadQueue.clear();
                });
              },
            ),
          ),
        ],
      ),
    );
  }
  Future<void> _saveBlobToFile(String base64Data, String suggestedName) async {
    try {
      // Decode the base64 data
      final bytes = base64Decode(base64Data);

      // Use the suggested name or fallback to a default
      final fileName = suggestedName.isNotEmpty ? suggestedName : 'file_${DateTime.now().millisecondsSinceEpoch}.png';

      // Open the save file dialog
      final FileSaveLocation? saveLocation = await getSaveLocation(suggestedName: fileName);
      if (saveLocation == null) {
        // User canceled the operation
        return;
      }

      // Save the file at the selected path
      final file = File(saveLocation.path);
      await file.writeAsBytes(bytes);

      final savedFileName = saveLocation.path.split('/').last;


      setState(() {
        downloadQueue.add({
          "fileName": savedFileName,
          "filePath": saveLocation.path,
        });
      });

      // Notify the user of the successful download
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("File saved to ${saveLocation.path}")),
      );
    } catch (e) {
      print("Error saving file: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to save file")),
      );
    }
  }

  Future<void> _handleDownload(String url) async {
    try {
      // Get the system's downloads directory
      final downloadsDirectory = await getDownloadsDirectory();
      if (downloadsDirectory == null) {
        throw Exception("Downloads directory not found");
      }

      // Determine file name from URL
      final fileName = url.split('/').last;

      // Target file path
      final filePath = '${downloadsDirectory.path}/$fileName';

      // Start the download
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);

        // Add to the download queue and update UI
        setState(() {
          downloadQueue.add({"fileName": fileName, "filePath": filePath});
        });
      } else {
        throw Exception("Failed to download file");
      }
    } catch (e) {
      print("Download error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to download file")),
      );
    }
  }

  @override
  bool get wantKeepAlive => true;
}

class DownloadPopup extends StatefulWidget {
  final VoidCallback onDismiss;

  const DownloadPopup({Key? key, required this.onDismiss}) : super(key: key);

  @override
  _DownloadPopupState createState() => _DownloadPopupState();
}

class _DownloadPopupState extends State<DownloadPopup> {
  List<FileSystemEntity> files = [];

  @override
  void initState() {
    super.initState();
    _loadDownloads();
  }

  Future<void> _loadDownloads() async {
    try {
      final downloadsDir = await getDownloadsDirectory();
      if (downloadsDir != null) {
        setState(() {
          files = downloadsDir.listSync();
        });
      }
    } catch (e) {
      print("Error loading downloads: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 4.0,
      child: Container(
        width: 300,
        color: Colors.white,
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Row with Title and Close Button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Downloads',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: widget.onDismiss,
                ),
              ],
            ),
            const Divider(),
            // List of Draggable File Items
            files.isEmpty
                ? const Text('No files in Downloads directory.')
                : ListView.builder(
              shrinkWrap: true,
              itemCount: files.length,
              itemBuilder: (context, index) {
                final file = files[index];
                if (file is! File) return const SizedBox();
                final fileName = file.path.split('/').last;
                return DragItemWidget(
                  dragItemProvider: (request) async {
                    print("drag requested");
                    final item = DragItem();
                    item.addVirtualFile(
                      format: Formats.pdf, // Adjust based on file type
                      provider: (sinkProvider, progress) async {
                        print("hilll");
                        final fileBytes = await file.readAsBytes();
                        final sink = sinkProvider(fileSize: fileBytes.length);
                        sink.add(fileBytes);
                        sink.close();
                      },
                    );
                    return item;
                  },
                  allowedOperations: () => [DropOperation.copy],
                  child: ListTile(
                    leading: Icon(Icons.insert_drive_file,
                        color: Colors.blue.shade700),
                    title: Text(fileName),
                    subtitle: Text(file.path),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}